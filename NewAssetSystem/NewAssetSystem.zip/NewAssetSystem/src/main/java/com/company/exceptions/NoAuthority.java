package com.company.exceptions;

public class NoAuthority extends Exception {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public NoAuthority(String str) {
		super(str);
	}
	

}
