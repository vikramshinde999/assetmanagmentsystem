package com.company.exceptions;

public class NoOrderFound  extends Exception{
	

	private static final long serialVersionUID = 1L;

	public NoOrderFound(String str) {
		super(str);
	}

}
